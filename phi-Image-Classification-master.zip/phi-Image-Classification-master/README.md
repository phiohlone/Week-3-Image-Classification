This repository introduces a quick setup guide for students who came to the 3rd meeting on the topic of Computer Vision and Image Classification.

